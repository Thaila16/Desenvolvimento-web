CREATE DATABASE lista;

use lista;

CREATE TABLE `loja` (
  `idlista` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  PRIMARY KEY (`idlista`));