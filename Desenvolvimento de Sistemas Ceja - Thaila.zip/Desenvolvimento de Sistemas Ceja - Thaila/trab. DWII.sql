CREATE DATABASE lista;

use lista;

CREATE TABLE `lista_nome` (
  `idlista` INT NOT NULL AUTO_INCREMENT,
  `nome_completo` VARCHAR(45) NULL,
  PRIMARY KEY (`idlista`));
  
select * from lista_nome;